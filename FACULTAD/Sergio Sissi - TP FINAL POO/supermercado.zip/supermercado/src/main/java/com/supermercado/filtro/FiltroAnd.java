package com.supermercado.filtro;

import com.supermercado.producto.Producto;

import java.util.List;

public class FiltroAnd implements Filtro {
    private Filtro filtro1;
    private Filtro filtro2;

    public FiltroAnd(Filtro filtro1, Filtro filtro2) {
        this.filtro1 = filtro1;
        this.filtro2 = filtro2;
    }

    @Override
    public boolean cumple(Producto producto){
        return (this.filtro1.cumple(producto) && this.filtro2.cumple(producto));
    }
}


