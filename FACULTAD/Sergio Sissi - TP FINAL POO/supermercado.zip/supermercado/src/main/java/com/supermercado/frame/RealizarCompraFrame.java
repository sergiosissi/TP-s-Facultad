package com.supermercado.frame;

import com.supermercado.producto.Producto;
import com.supermercado.producto.ProductoSimple;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RealizarCompraFrame extends JFrame {

    private JTable tablaProductos;
    private DefaultTableModel modeloTabla;
    private JTextField txtTotal;
    private double total;
    private List<Producto> productosSeleccionados;

    public RealizarCompraFrame() {
        // Configurar la ventana
        setTitle("Realizar Compra");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Crear la tabla para mostrar los productos
        tablaProductos = new JTable();
        modeloTabla = new DefaultTableModel(new Object[]{"Nombre", "Departamento", "Precio"}, 0);
        tablaProductos.setModel(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaProductos);

        // Crear el campo de texto para mostrar el monto total
        txtTotal = new JTextField();
        txtTotal.setEditable(false);
        txtTotal.setColumns(10);

        // Crear los botones para agregar y eliminar productos
        JButton btnAgregar = new JButton("Agregar");
        btnAgregar.addActionListener(e -> {
            int filaSeleccionada = tablaProductos.getSelectedRow();
            if (filaSeleccionada != -1) {
                List<Producto> productos = cargarProductos();
                Producto productoSeleccionado = productos.get(filaSeleccionada);
                productosSeleccionados.add(productoSeleccionado);
                total += productoSeleccionado.getPrecio();
                txtTotal.setText("Total: $" + total);
            }
        });

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.addActionListener(e -> {
            int filaSeleccionada = tablaProductos.getSelectedRow();
            if (filaSeleccionada != -1) {
                Producto productoSeleccionado = productosSeleccionados.get(filaSeleccionada);
                productosSeleccionados.remove(productoSeleccionado);
                total -= productoSeleccionado.getPrecio();
                txtTotal.setText("Total: $" + total);
            }
        });

        // Agregar los componentes a la ventana
        JPanel panelBotones = new JPanel();
        panelBotones.add(btnAgregar);
        panelBotones.add(btnEliminar);

        JPanel panelTotal = new JPanel();
        panelTotal.add(new JLabel("Total:"));
        panelTotal.add(txtTotal);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(scrollPane, BorderLayout.CENTER);
        getContentPane().add(panelBotones, BorderLayout.NORTH);
        getContentPane().add(panelTotal, BorderLayout.SOUTH);

        // Cargar los productos desde la base de datos
        List<Producto> productos = cargarProductos();
        for (Producto producto : productos) {
            modeloTabla.addRow(new Object[]{producto.getNombre(), producto.getDepartamento(), producto.getPrecio()});
        }

        // Inicializar la lista de productos seleccionados
        productosSeleccionados = new ArrayList<>();
    }

    private List<Producto> cargarProductos() /*throws SQLException*/{
        // Aquí iría el código para cargar los productos desde la base de datos
        // Se puede utilizar una clase DAO o cualquier otro enfoque para acceder a la base de datos
        List<Producto> productos = new ArrayList<>();
        ProductoSimple leche = new ProductoSimple("Leche", 100.00, 100, "Lacteos" );
        ProductoSimple yogur = new ProductoSimple("yogur", 150.00, 100, "Lacteos" );

        productos.add(leche);
        productos.add(yogur);
        return productos;
    }
}
